clear,figure(1),clf
% niumerics
nx = 50;
nt = 200;
% init vectors
TL = 1*ones(nx,1);
TR = 2*ones(nx,1);
Tg = [TL(1:end-1);TR(2:end)];
nn = 1:size(Tg,1);
% action
for it=1:nt
    TL(2:end-1) = TL(2:end-1) + diff(diff(TL))/4;
    TR(2:end-1) = TR(2:end-1) + diff(diff(TR))/4;
    % update boundaries (MPI)
    TL(end) = TR(2);  TR(1) = TL(end-1);
    % global picture
    T = [TL(1:end-1);TR(2:end)];
    % post-process
    plot(nn,T,'ro',nn,Tg,'-b'),title(it),drawnow
    % compute physics locally
    Tg(2:end-1) = Tg(2:end-1) + diff(diff(Tg))/4;
end
